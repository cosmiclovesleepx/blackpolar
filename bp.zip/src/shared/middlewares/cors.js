import cors from 'cors';

/**
 * Configuración de CORS para cada aplicación
 */
export const setupCORS = (app) => {
  const allowedOrigins = process.env.CORS_ORIGIN?.split(',') || '*';

  app.use(
    cors({
      origin: allowedOrigins,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization'],
      credentials: true,
      maxAge: 86400, // 24 hours
    })
  );
};
