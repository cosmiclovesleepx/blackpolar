import morgan from 'morgan';

/**
 * Configuración de logging con Morgan
 */
export const setupLogging = (app) => {
  if (process.env.NODE_ENV === 'development') {
    // Formato detallado en desarrollo
    app.use(morgan('dev'));
  } else {
    // Formato compacto en producción
    app.use(morgan('combined'));
  }
};
