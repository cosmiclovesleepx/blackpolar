/**
 * Middleware para rutas no encontradas 404
 * Debe ir después de todas las otras rutas
 */
export const notFound = (req, res, next) => {
  res.status(404).json({
    success: false,
    error: {
      message: `Ruta no encontrada: ${req.method} ${req.path}`,
      statusCode: 404,
    },
  });
};
