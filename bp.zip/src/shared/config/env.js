import dotenv from 'dotenv';

dotenv.config();

const corsOrigins = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(',').map(origin => origin.trim())
  : ['*'];

export const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  
  // Main App
  MAIN_PORT: process.env.MAIN_PORT || 3000,
  
  // Portfolios App
  PORTFOLIOS_PORT: process.env.PORTFOLIOS_PORT || 4000,
  
  // TLM App
  TLM_PORT: process.env.TLM_PORT || 5000,
  
  // Database
  MONGODB_URI:
    process.env.MONGODB_URI ||
    'mongodb://obsidian-db-admin:e2rGo5IehihqGW5E@ac-vfspmaw-shard-00-00.aowmsyz.mongodb.net:27017,ac-vfspmaw-shard-00-01.aowmsyz.mongodb.net:27017,ac-vfspmaw-shard-00-02.aowmsyz.mongodb.net:27017/?ssl=true&replicaSet=atlas-jeb6nv-shard-0&authSource=admin&appName=Obsidian-DB-1',
  
  // JWT
  JWT_SECRET: process.env.JWT_SECRET || 'dev-secret-key',
  JWT_EXPIRE: process.env.JWT_EXPIRE || '7d',
  
  // CORS ARREGLADO
  cors: {
    origins: corsOrigins
  },

  // Rate Limit
    rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX) || 100
    },
  
  // Environment flags
  isDevelopment: process.env.NODE_ENV === 'development',
  isProduction: process.env.NODE_ENV === 'production',
  isTesting: process.env.NODE_ENV === 'test',
};

export const validateEnv = () => {
  const requiredVars = ['MONGODB_URI'];

  if (env.isProduction) {
    const missing = requiredVars.filter(key => !process.env[key]);
    if (missing.length > 0) {
      throw new Error(
        `Missing required environment variables: ${missing.join(', ')}`
      );
    }
  }
};