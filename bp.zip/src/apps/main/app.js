/**
 * app.js
 * Aplicación Express unificada.
 *
 * Combina lo mejor de ambas versiones:
 *  - Configuración centralizada vía config/env.js
 *  - Middlewares compartidos desde shared/ (logging, cors, errors)
 *  - Seguridad completa con helmet + rate limiting + compresión
 *  - Static files con ruta explícita /public + serveIndex en dev
 *  - Motor de vistas EJS con viewGuard contra path traversal
 *  - Trust proxy para despliegues detrás de Nginx / load balancers
 *  - Health check enriquecido con uptime y environment
 *  - Rutas API modulares listas para montar
 */

import express     from 'express';
import helmet      from 'helmet';
import compression from 'compression';
import rateLimit   from 'express-rate-limit';
import serveIndex  from 'serve-index';
import path        from 'path';
import { fileURLToPath } from 'url';

// ── Shared middlewares (de la segunda app) ────────────────────────
import { setupLogging } from '../../shared/middlewares/logging.js';
import { setupCORS }    from '../../shared/middlewares/cors.js';
import { notFound }     from '../../shared/middlewares/notFound.js';
import { errorHandler } from '../../shared/middlewares/errorHandler.js';

// ── Config y middlewares locales (de la primera app) ──────────────
import { env }    from '../../shared/config/env.js';
import { viewGuard } from '../../shared/middlewares/viewGuard.js';

// ── Rutas ─────────────────────────────────────────────────────────
// import authRoutes     from './routes/auth.js';
// import usersRoutes    from './routes/users.js';
// import productsRoutes from './routes/products.js';

// ── ESM __dirname ─────────────────────────────────────────────────
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ═════════════════════════════════════════════════════════════════
const app = express();

// ── 1. TRUST PROXY ───────────────────────────────────────────────
// Necesario detrás de Nginx, AWS ALB, Cloudflare, etc.
// Permite leer X-Forwarded-For y X-Forwarded-Proto correctamente.
app.set('trust proxy', 1);

// ── 2. SEGURIDAD — Helmet ────────────────────────────────────────
// En dev deshabilitamos CSP para que CDNs y live-reload funcionen.
// En prod aplicamos la política por defecto (más restrictiva).
app.use(
  helmet({
    contentSecurityPolicy: false
  })
);

// ── 3. CORS ──────────────────────────────────────────────────────
// setupCORS centraliza la lógica compartida entre apps.
// Si necesitas sobreescribir origins solo para esta app, pasa opciones:
setupCORS(app, {
  origin:      env.cors.origins,
  credentials: true,
  methods:     ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
});

// ── 4. RATE LIMITING ─────────────────────────────────────────────
// Protección global contra fuerza bruta y DDoS básico.
// Configurable desde .env (RATE_LIMIT_WINDOW_MS / RATE_LIMIT_MAX).
app.use(rateLimit({
  windowMs:        env.rateLimit.windowMs,
  max:             env .rateLimit.max,
  standardHeaders: true,  // RateLimit-* headers (RFC 6585)
  legacyHeaders:   false, // Desactiva X-RateLimit-* obsoletos
  message: {
    status:  'error',
    message: 'Demasiadas peticiones, intenta más tarde.',
    code:    429,
  },
}));

// ── 5. RENDIMIENTO — Compresión ──────────────────────────────────
// gzip / brotli para todas las respuestas text/*.
app.use(compression());

// ── 6. LOGGING ───────────────────────────────────────────────────
// setupLogging aplica morgan con el formato correcto según entorno
// (combined en prod, dev en desarrollo).
setupLogging(app);

// ── 7. PARSERS ───────────────────────────────────────────────────
// Límite de 10mb para compatibilidad con uploads de la segunda app.
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// ── 8. ESTILOS GLOBALES COMPARTIDOS ──────────────────────────────
// Serve archivos CSS compilados desde src/shared/styles
// Ruta accesible en: localhost:PORT/styles/output.css
app.use('/styles', express.static(path.join(__dirname, '../../shared/styles'), {
  maxAge:   env.isProd ? '1d' : 0,  // Cache en prod, sin cache en dev
  dotfiles: 'deny',                    // Bloquea .env, .htaccess, etc.
  index:    false,                     // Desactiva index.html automático
}));

// ── 9. MOTOR DE VISTAS (EJS) ─────────────────────────────────────
// Ruta explícita y portable usando __dirname (no strings relativos).
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ── 10. ARCHIVOS ESTÁTICOS ────────────────────────────────────────
// Ruta explícita: localhost:PORT/public/css/index.css
//                 localhost:PORT/public/js/index.js
app.use('/public', express.static(path.join(__dirname, 'public'), {
  maxAge:   env.isProd ? '1d' : 0,  // Cache en prod, sin cache en dev
  dotfiles: 'deny',                    // Bloquea .env, .htaccess, etc.
  index:    false,                     // Desactiva index.html automático
}));

// Listado de directorios solo en desarrollo (nunca exponer en prod)
if (env.isDev) {
  app.use('/public', serveIndex(path.join(__dirname, 'public'), {
    icons: true,
    view:  'details',
  }));
}

// ── 11. HEALTH CHECK ─────────────────────────────────────────────
// Enriquecido con uptime (segunda app) + env y app name (primera app).
// Compatible con Docker HEALTHCHECK, K8s liveness probes y ALBs.
app.get('/health', (req, res) => {
  res.json({
    status:    'success',
    app:       env.appName,
    env:       env.env,
    uptime:    process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// ── 12. RUTA RAÍZ ────────────────────────────────────────────────
// Renderiza views/index.ejs con el nombre de la app desde config.
app.get('/', (req, res) => {
  res.render('index', { appName: env.appName });
});

// ── 13. RUTAS DE API ─────────────────────────────────────────────
// Bloque principal de rutas (importado desde routes/index.js).
// Debe ir ANTES de viewGuard para que las rutas /api/* no sean
// interceptadas como vistas EJS.

// Rutas adicionales — descomenta según necesidad:
// app.use('/api/auth',     authRoutes);
// app.use('/api/users',    usersRoutes);
// app.use('/api/products', productsRoutes);

// ── 14. RUTAS DINÁMICAS EJS (con protección path traversal) ──────
// Captura /:view DESPUÉS de las rutas de API para no colisionar.
// viewGuard valida contra lista blanca y bloquea ../ y similares.
app.get('/:view', viewGuard);

// ── 15. ERROR HANDLING (siempre al final) ────────────────────────
app.use(notFound);
app.use(errorHandler);

export default app;