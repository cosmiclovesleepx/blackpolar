/**
 * Black Polar - Main Application Script
 * Handles all interactive features, animations, and form processing
 * Compatible with strict Content Security Policy (no unsafe-inline)
 */

// ════════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ════════════════════════════════════════════════════════════════

const log = {
  info: (message, data = '') => {
    console.log(`%c[INFO]%c ${message}`, 'color: #3498db; font-weight: bold;', 'color: inherit;', data);
  },
  success: (message, data = '') => {
    console.log(`%c[SUCCESS]%c ${message}`, 'color: #2ecc71; font-weight: bold;', 'color: inherit;', data);
  },
  warn: (message, data = '') => {
    console.warn(`%c[WARN]%c ${message}`, 'color: #f39c12; font-weight: bold;', 'color: inherit;', data);
  },
  error: (message, data = '') => {
    console.error(`%c[ERROR]%c ${message}`, 'color: #e74c3c; font-weight: bold;', 'color: inherit;', data);
  },
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

// ════════════════════════════════════════════════════════════════
// DATA MODEL
// ════════════════════════════════════════════════════════════════

const data = {
  services: [
    {
      number: "01",
      name: "Technology Services",
      description: "End-to-end IT solutions encompassing infrastructure design, deployment, and management. We architect and maintain the digital backbone that keeps your organization running without interruption.",
      tags: ["Cloud Migration", "Infrastructure", "DevOps", "24/7 Support"],
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" class="service-icon"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>`
    },
    {
      number: "02",
      name: "Cybersecurity",
      description: "Proactive threat intelligence, penetration testing, and enterprise-grade defense architectures. We identify vulnerabilities before adversaries do and build layered protection across your entire attack surface.",
      tags: ["Pen Testing", "SOC", "Zero Trust", "Compliance"],
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" class="service-icon"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`
    },
    {
      number: "03",
      name: "Systems Administration",
      description: "Reliable management of Linux, Windows, and hybrid environments. From patch management to performance optimization, we ensure your systems are stable, secure, and performing at their peak.",
      tags: ["Linux/Unix", "Windows Server", "Virtualization", "Monitoring"],
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" class="service-icon"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>`
    },
    {
      number: "04",
      name: "Strategic Consulting",
      description: "Technology strategy aligned to business outcomes. We partner with leadership to map digital transformation roadmaps, evaluate vendor ecosystems, and build investment cases for critical technology decisions.",
      tags: ["Digital Transformation", "IT Strategy", "Audit", "Roadmapping"],
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" class="service-icon"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>`
    }
  ],

  portfolio: [
    {
      title: "Financial Infrastructure Overhaul",
      category: "Systems Architecture",
      image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=900&q=80&auto=format&fit=crop",
      span: "md:col-span-7",
      height: "380px"
    },
    {
      title: "Zero-Trust Security Framework",
      category: "Cybersecurity",
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&q=80&auto=format&fit=crop",
      span: "md:col-span-5",
      height: "380px"
    },
    {
      title: "Multi-Cloud Migration",
      category: "Cloud Engineering",
      image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&q=80&auto=format&fit=crop",
      span: "md:col-span-5",
      height: "320px"
    },
    {
      title: "Enterprise SOC Implementation",
      category: "Security Operations",
      image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=900&q=80&auto=format&fit=crop",
      span: "md:col-span-7",
      height: "320px"
    }
  ]
};

// ════════════════════════════════════════════════════════════════
// TEMPLATE RENDERING FUNCTIONS
// ════════════════════════════════════════════════════════════════

function renderTemplate(templateFn, item) {
  return templateFn(item);
}

function serviceTemplate(s) {
  return `
    <div class="service-card bg-service reveal">
      <div class="service-number">${s.number}</div>
      ${s.icon}
      <h3 class="service-name">${s.name}</h3>
      <p class="service-desc">${s.description}</p>
      <div class="service-tags">
        ${s.tags.map(t => `<span class="service-tag">${t}</span>`).join('')}
      </div>
    </div>
  `;
}

function portfolioTemplate(p) {
  // Sanitize height to prevent CSS injection
  const heightMap = {
    '380px': 'portfolio-h-380',
    '320px': 'portfolio-h-320'
  };
  const heightClass = heightMap[p.height] || 'portfolio-h-380';
  
  return `
    <div class="portfolio-item ${p.span} reveal ${heightClass}">
      <img src="${p.image}" alt="${p.title}" loading="lazy" />
      <div class="portfolio-overlay">
        <div class="portfolio-title">${p.title}</div>
        <div class="portfolio-cat">${p.category}</div>
      </div>
    </div>
  `;
}

// ════════════════════════════════════════════════════════════════
// RENDER INITIAL CONTENT
// ════════════════════════════════════════════════════════════════

function initializeContent() {
  const servicesGrid = document.getElementById('services-grid');
  const portfolioGrid = document.getElementById('portfolio-grid');

  if (servicesGrid) {
    servicesGrid.innerHTML = data.services
      .map(s => renderTemplate(serviceTemplate, s))
      .join('');
  }

  if (portfolioGrid) {
    portfolioGrid.innerHTML = data.portfolio
      .map(p => renderTemplate(portfolioTemplate, p))
      .join('');
  }
}

// ════════════════════════════════════════════════════════════════
// SCROLL-BASED HEADER
// ════════════════════════════════════════════════════════════════

function initializeScrollHeader() {
  const header = document.getElementById('site-header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 60);
  });
}

// ════════════════════════════════════════════════════════════════
// INTERSECTION OBSERVER FOR REVEAL ANIMATIONS
// ════════════════════════════════════════════════════════════════

function initializeRevealAnimations() {
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        revealObserver.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.reveal').forEach(el => {
    revealObserver.observe(el);
  });
}

// ════════════════════════════════════════════════════════════════
// ANIMATED STATS COUNTER
// ════════════════════════════════════════════════════════════════

function initializeStatsCounter() {
  const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const el = e.target;
        const target = parseInt(el.getAttribute('data-count'));
        const suffix = el.textContent.replace(/\d+/, '').trim();
        let current = 0;
        const step = Math.ceil(target / 50);
        const timer = setInterval(() => {
          current = Math.min(current + step, target);
          el.textContent = current + suffix;
          if (current >= target) clearInterval(timer);
        }, 28);
        statsObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-count]').forEach(el => {
    statsObserver.observe(el);
  });
}

// ════════════════════════════════════════════════════════════════
// ADMIN BUTTON HANDLER
// ════════════════════════════════════════════════════════════════

function initializeAdminButton() {
  const adminBtn = document.getElementById('admin-btn');
  if (!adminBtn) return;

  adminBtn.addEventListener('click', () => {
    alert('Admin login');
  });
}

// ════════════════════════════════════════════════════════════════
// FORM SUBMISSION HANDLER
// ════════════════════════════════════════════════════════════════

function handleFormSubmit(e) {
  e.preventDefault();
  const btn = e.currentTarget;
  
  // Store original HTML
  const originalHTML = btn.innerHTML;
  
  // Change button state
  btn.classList.add('form-submitted');
  btn.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
    Message Sent`;
  
  // Reset after 4 seconds
  setTimeout(() => {
    btn.classList.remove('form-submitted');
    btn.innerHTML = originalHTML;
  }, 4000);
}

function initializeFormSubmit() {
  const contactForm = document.querySelector('.contact-wrapper');
  if (!contactForm) return;

  const submitBtn = contactForm.querySelector('button[data-form-submit]');
  if (submitBtn) {
    submitBtn.addEventListener('click', handleFormSubmit);
  }
}

// ════════════════════════════════════════════════════════════════
// MOBILE MENU TOGGLE
// ════════════════════════════════════════════════════════════════

function initializeMobileMenu() {
  const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');

  if (!mobileMenuToggle || !mobileMenu) return;

  // Toggle menu on button click
  mobileMenuToggle.addEventListener('click', () => {
    mobileMenuToggle.classList.toggle('active');
    mobileMenu.classList.toggle('active');
  });

  // Close menu when a link is clicked
  mobileNavLinks.forEach(link => {
    link.addEventListener('click', () => {
      mobileMenuToggle.classList.remove('active');
      mobileMenu.classList.remove('active');
    });
  });

  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    const isClickInsideNav = mobileMenu.contains(e.target);
    const isClickOnToggle = mobileMenuToggle.contains(e.target);
    
    if (!isClickInsideNav && !isClickOnToggle && mobileMenu.classList.contains('active')) {
      mobileMenuToggle.classList.remove('active');
      mobileMenu.classList.remove('active');
    }
  });

  // Close menu on window resize (back to desktop view)
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      mobileMenuToggle.classList.remove('active');
      mobileMenu.classList.remove('active');
    }
  });
}

// ════════════════════════════════════════════════════════════════
// CURSOR TRACKING (Custom Cursor)
// ════════════════════════════════════════════════════════════════

function initializeCursorTracking() {
  const cursor = document.getElementById('cursor');
  const ring = document.getElementById('ring');

  if (!cursor || !ring) return;

  document.addEventListener('mousemove', (e) => {
    cursor.style.left = e.clientX + 'px';
    cursor.style.top = e.clientY + 'px';
    ring.style.left = (e.clientX - 18) + 'px';
    ring.style.top = (e.clientY - 18) + 'px';
  });

  // Expand on interactive elements
  document.querySelectorAll('a, button, input, textarea, select').forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursor.classList.add('cursor-hover');
      ring.classList.add('ring-hover');
    });
    
    el.addEventListener('mouseleave', () => {
      cursor.classList.remove('cursor-hover');
      ring.classList.remove('ring-hover');
    });
  });
}

// ════════════════════════════════════════════════════════════════
// INITIALIZE ALL
// ════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
  log.info('Black Polar App Initializing');

  initializeContent();
  initializeScrollHeader();
  initializeRevealAnimations();
  initializeStatsCounter();
  initializeAdminButton();
  initializeFormSubmit();
  initializeMobileMenu();
  initializeCursorTracking();

  log.success('Black Polar App Ready');
});
