import express from 'express';
import helmet from 'helmet';
import path from 'path';
import { fileURLToPath } from 'url';
import { setupLogging } from '../../shared/middlewares/logging.js';
import { setupCORS } from '../../shared/middlewares/cors.js';
import { notFound } from '../../shared/middlewares/notFound.js';
import { errorHandler } from '../../shared/middlewares/errorHandler.js';
import tlmRoutes from './routes/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Trust proxy for production (when behind Nginx)
app.set('trust proxy', 1);

// Security - CSP disabled for development
app.use(helmet({
  contentSecurityPolicy: false
}));

// Logging
setupLogging(app);

// CORS
setupCORS(app);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Global shared styles
app.use('/styles', express.static(path.join(__dirname, '../../shared/styles'), {
  dotfiles: 'deny',
  index: false,
}));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Health check
app.get('/health', (req, res) => {
  res.json({
    success: true,
    app: 'tlm',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// Routes
app.use('/', tlmRoutes);

// 404 Not Found
app.use(notFound);

// Error handling
app.use(errorHandler);

export default app;
