import { Router } from 'express';

const router = Router();

/**
 * TLM App Routes
 */

router.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🚀 Welcome to TLM App (tlm.midominio.com)',
    app: 'tlm',
    endpoints: {
      health: '/health',
      api: '/api/v1',
    },
    timestamp: new Date().toISOString(),
  });
});

router.get('/api/v1', (req, res) => {
  res.json({
    success: true,
    message: 'TLM API v1 - Ready to use',
    version: '1.0.0',
  });
});

router.get('/services', (req, res) => {
  res.json({
    success: true,
    app: 'TLM App',
    description: 'Total Learning Management system',
    services: [
      { name: 'Courses', route: '/courses' },
      { name: 'Users', route: '/users' },
      { name: 'Analytics', route: '/analytics' },
    ],
  });
});

export default router;
