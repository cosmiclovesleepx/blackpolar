import { Router } from 'express';

const router = Router();

/**
 * Portfolios App Routes
 */

router.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🎨 Welcome to Portfolios App (portfolios.midominio.com)',
    app: 'portfolios',
    endpoints: {
      health: '/health',
      api: '/api/v1',
    },
    timestamp: new Date().toISOString(),
  });
});

router.get('/api/v1', (req, res) => {
  res.json({
    success: true,
    message: 'Portfolios API v1 - Ready to use',
    version: '1.0.0',
  });
});

router.get('/gallery', (req, res) => {
  res.json({
    success: true,
    app: 'Portfolios App',
    description: 'Gallery of professional portfolios',
    portfolios: [
      { id: 1, title: 'Portfolio 1', slug: 'portfolio-1' },
      { id: 2, title: 'Portfolio 2', slug: 'portfolio-2' },
    ],
  });
});

export default router;
