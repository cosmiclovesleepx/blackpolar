import app from './app.js';
import { env, validateEnv } from '../../shared/config/env.js';
import { connectDB } from '../../shared/config/db.js';
import { logger } from '../../shared/utils/logger.js';

const PORT = env.PORTFOLIOS_PORT;

const startServer = async () => {
  try {
    // Validate environment variables
    validateEnv();
    logger.info('Environment variables validated');

    // Connect to MongoDB
    await connectDB();

    // Start HTTP server
    const server = app.listen(PORT, () => {
      logger.success(
        `PORTFOLIOS app running on http://localhost:${PORT}`,
        `(Environment: ${env.NODE_ENV})`
      );
    });

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      logger.warn('SIGTERM signal received: closing HTTP server');
      server.close(() => {
        logger.info('HTTP server closed');
        process.exit(0);
      });
    });

    process.on('SIGINT', async () => {
      logger.warn('SIGINT signal received: closing HTTP server');
      server.close(() => {
        logger.info('HTTP server closed');
        process.exit(0);
      });
    });
  } catch (error) {
    logger.error('Failed to start server:', error.message);
    process.exit(1);
  }
};

startServer();

export default app;
